import-module servermanager
Add-WindowsFeature web-server -IncludeAllSubFeature